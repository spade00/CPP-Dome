#pragma once
#include<string>
#include<Windows.h>
#include<fstream>
#include"Administrator.h"
#include<iostream>
using namespace std;
class virtaul
{
	string pass;
 public:
	 virtaul(string);
	 virtaul();
	 //virtual void show() = 0;
	 void verify111();
};
