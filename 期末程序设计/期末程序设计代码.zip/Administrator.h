#pragma once
#include<string>
using namespace std;
class Administrator
{
public:
	void show();
	Administrator();
};

