#pragma once
class Customer
{
public:
	void Customer_interface();
};

